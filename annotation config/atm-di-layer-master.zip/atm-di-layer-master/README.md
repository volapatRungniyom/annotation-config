# ATM Example

Dependency injection with a layer of indirection.

